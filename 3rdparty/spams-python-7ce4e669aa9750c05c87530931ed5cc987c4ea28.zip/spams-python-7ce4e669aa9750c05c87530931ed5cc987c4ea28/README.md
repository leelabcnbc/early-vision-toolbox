spams-python
============

A swig-regenerated rehost of the python version of SPArse Modeling Software (SPAMS) 2.5, available at http://spams-devel.gforge.inria.fr/downloads.html
